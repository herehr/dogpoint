import prisma from '../services/prisma';

async function main() {
  await prisma.animal.create({
    data: {
      name: 'Fluffy',
      description: 'A fluffy dog',
      galerie: {
        create: [
          { url: 'https://example.com/photo.jpg', type: 'image' },
          { url: 'https://example.com/video.mp4', type: 'video' },
        ],
      },
    },
  });
  console.log('✅ Seed data created');
}

main()
  .catch(e => console.error(e))
  .finally(() => prisma.$disconnect());