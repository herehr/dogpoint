import * as express from 'express';
import { getAllModerators } from '../controllers/moderatorController';
import { checkAdmin } from '../middleware/checkAdmin';

const router = express.Router();

router.get('/', checkAdmin, getAllModerators);

export default router;