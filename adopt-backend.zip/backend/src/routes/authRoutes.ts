import express from 'express';
import { login } from '../controllers/authController';
import { generateToken, checkRole } from '../services/auth';
import { Role } from '@prisma/client'; // ✅ IMPORT ENUM

const router = express.Router();

// 🔧 Test token generation
router.post('/test', (req, res) => {
  const token = generateToken({ id: 'admin123', role: Role.ADMIN });
  res.json({ token });
});

// 🔐 Real login route
router.post('/login', login);

// ✅ PROTECTED route (requires valid JWT and allowed role)
router.get('/protected', checkRole([Role.ADMIN, Role.MODERATOR, Role.USER]), (req, res) => {
  res.json({
    message: 'You accessed a protected route!',
    user: req.user,
  });
});

export default router;