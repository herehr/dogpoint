import { Request, Response } from 'express';
import prisma from '../services/prisma';

export const getAllModerators = async (req: Request, res: Response) => {
  try {
    const moderators = await prisma.user.findMany({
      where: { role: 'MODERATOR' },
      select: { id: true, email: true, name: true },
    });
    res.json(moderators);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch moderators' });
  }
};