import express, { Request } from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import { Role } from '@prisma/client';
import authRoutes from './routes/authRoutes';

dotenv.config();

const app = express();

// --- Middleware ---
app.use(cors());
app.use(express.json());

// --- API Routes ---
app.use('/api/auth', authRoutes);

// --- Custom Typing for req.user ---
declare module 'express-serve-static-core' {
  interface Request {
    user?: {
      id: string;
      role: Role;
    };
  }
}

// --- Server Start ---
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});