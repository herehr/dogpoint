import { Request, Response, NextFunction } from 'express';
import * as jwt from 'jsonwebtoken';

export const checkAdmin = (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Missing token' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as { role: string };
    if (decoded.role !== 'ADMIN') return res.status(403).json({ error: 'Admin access required' });
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};