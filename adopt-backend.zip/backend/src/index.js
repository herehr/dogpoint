"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express = require("express");
var cors = require("cors");
var dotenv = require("dotenv");
var animalRoutes_1 = require("./routes/animalRoutes");
var authRoutes_1 = require("./routes/authRoutes");
var moderatorRoutes_1 = require("./routes/moderatorRoutes");
dotenv.config();
var app = express();
app.use(cors());
app.use(express.json());
app.use('/api/animals', animalRoutes_1.default);
app.use('/api/auth', authRoutes_1.default);
app.use('/api/moderators', moderatorRoutes_1.default);
var PORT = process.env.PORT || 3000;
app.listen(PORT, function () {
    console.log("\uD83D\uDE80 Backend running on port ".concat(PORT));
});
